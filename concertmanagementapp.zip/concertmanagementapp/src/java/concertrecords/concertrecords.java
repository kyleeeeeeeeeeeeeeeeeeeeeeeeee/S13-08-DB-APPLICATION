package concertrecords;

import java.sql.*;

public class ConcertRecords {

    private Connection connection;

    // Constructor to initialize the connection
    public ConcertRecords(Connection connection) {
        this.connection = connection;
    }

    // Method to view the ticket record and return it as a String for JSP rendering
    public String ticketRecord(int ticketCode) {
        String query = """
        SELECT
            Tickets.ticket_code, Tickets.ticket_price, Tickets.seat_number, Tickets.ticket_type,
            Concerts.concert_title, Concerts.performer_name, Concerts.concert_date,
            Venues.venue_name, Transactions.transaction_date, Transactions.transaction_type,
            Customers.first_name AS customer_first_name,
            Customers.last_name AS customer_last_name, Customers.email AS customer_email,
            Customers.contact_number AS customer_contact
        FROM Tickets
        JOIN Concerts ON Tickets.concert_code = Concerts.concert_code
        JOIN Artists ON Concerts.artist_code = Artists.artist_code
        JOIN Venues ON Concerts.venue_code = Venues.venue_code
        JOIN Transactions ON Tickets.transaction_code = Transactions.transaction_code
        JOIN Customers ON Transactions.customer_code = Customers.customer_code
        WHERE Tickets.ticket_code = ?;
       """;

        StringBuilder result = new StringBuilder();
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, ticketCode);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.append("<h2>Ticket Details</h2>")
                          .append("<p>Ticket Code: ").append(rs.getInt("ticket_code")).append("</p>")
                          .append("<p>Ticket Price: ₱").append(rs.getBigDecimal("ticket_price")).append("</p>")
                          .append("<p>Seat Type: ").append(rs.getString("ticket_type")).append("</p>")
                          .append("<p>Seat Number: ").append(rs.getString("seat_number")).append("</p>")
                          .append("<p>Transacted: ").append(rs.getTimestamp("transaction_date")).append("</p>")
                          .append("<h2>Concert Details</h2>")
                          .append("<p>Event Name: ").append(rs.getString("concert_title")).append("</p>")
                          .append("<p>Performer: ").append(rs.getString("performer_name")).append("</p>")
                          .append("<p>Concert Date: ").append(rs.getDate("concert_date")).append("</p>")
                          .append("<p>Venue: ").append(rs.getString("venue_name")).append("</p>")
                          .append("<h2>Customer Details</h2>")
                          .append("<p>Name: ").append(rs.getString("customer_first_name"))
                          .append(" ").append(rs.getString("customer_last_name")).append("</p>")
                          .append("<p>Email: ").append(rs.getString("customer_email")).append("</p>")
                          .append("<p>Contact Number: ").append(rs.getString("customer_contact")).append("</p>");

                    String transactionType = rs.getString("transaction_type");
                    if ("transfer".equalsIgnoreCase(transactionType)) {
                        result.append("<p>Original Buyer: Transferred ticket</p>");
                    } else {
                        result.append("<p>Original Buyer: Yes</p>");
                    }
                } else {
                    result.append("<p>No ticket record found for Ticket Code: ").append(ticketCode).append("</p>");
                }
            }
        } catch (SQLException e) {
            result.append("<p>Error fetching ticket record: ").append(e.getMessage()).append("</p>");
        }
        return result.toString();
    }

    // Static method to establish a connection to the database
    public static Connection getConnection() {
        String url = "jdbc:mysql://localhost:3306/concerttix";
        String user = "root";
        String password = "Is!ma2friend3";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("Connection failed: " + e.getMessage());
            return null;
        }
    }
}
